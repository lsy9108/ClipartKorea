// in-box load effect
$('.content-img').css({top:"60%"});
$('.content-headline').addClass('in');
$('.content-sidetext').addClass('in');
//$('.content-img:after').css({letterSpacing:'0.2em'})